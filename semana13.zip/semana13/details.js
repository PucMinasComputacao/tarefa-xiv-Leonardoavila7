const params = new URLSearchParams(window.location.search);
const id = params.get("id");

const container = document.getElementById("details-container");

async function fetchItem() {

  if (!id) {
    container.innerHTML = "<h2>ID não informado.</h2>";
    return;
  }

  try {
    const response = await fetch(`http://localhost:3000/materiais/${id}`);

    if (!response.ok) {
      throw new Error("Item não encontrado");
    }

    const item = await response.json();

    renderItem(item);

  } catch (error) {
    container.innerHTML = `<h2>${error.message}</h2>`;
  }
}

function renderItem(item) {

  container.innerHTML = `
    <div class="details-card">
      <img src="${item.imagem}" alt="${item.titulo}">
      <h1>${item.titulo}</h1>
      <p><strong>Categoria:</strong> ${item.categoria}</p>
      <p><strong>Valor:</strong> R$ ${item.valor}</p>
      <p>${item.descricaoCompleta}</p>

      <div class="tags">
        ${item.tags.map(tag => `<span>${tag}</span>`).join("")}
      </div>

      <a href="index.html">Voltar</a>
    </div>
  `;
}

fetchItem();