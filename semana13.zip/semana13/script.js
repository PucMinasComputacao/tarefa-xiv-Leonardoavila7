const API_URL = "http://localhost:3000/materiais";

async function fetchItems() {
  const response = await fetch(API_URL);
  return await response.json();
}

function createCard(item) {
  const card = document.createElement("div");
  card.classList.add("card");

  card.innerHTML = `
    <img src="${item.imagem}" alt="${item.titulo}">
    <h2>${item.titulo}</h2>
    <p>${item.descricaoCurta}</p>
    <span>${item.categoria}</span>
    <strong>R$ ${item.valor}</strong>
    <a href="details.html?id=${item.id}">Ver detalhes</a>
  `;

  return card;
}

function renderCards(items) {
  const container = document.getElementById("cards-container");

  container.innerHTML = "";

  items.forEach(item => {
    const card = createCard(item);
    container.appendChild(card);
  });
}

async function init() {
  const items = await fetchItems();
  renderCards(items);
}

init();